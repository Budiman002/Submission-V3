const PlaylistsHandler = require('./handler');
const routes = require('./routes');

module.exports = {
  name: 'playlists',
  version: '1.0.0',
  register: async (server, { service, songsService, validator, authMiddleware }) => {
    const playlistsHandler = new PlaylistsHandler(service, songsService, validator);
    server.route(routes(playlistsHandler, authMiddleware));
  },
};